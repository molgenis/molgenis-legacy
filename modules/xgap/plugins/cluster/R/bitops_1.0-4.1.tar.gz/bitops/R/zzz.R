.First.lib <- function(lib, pkg) library.dynam("bitops",pkg,lib)
